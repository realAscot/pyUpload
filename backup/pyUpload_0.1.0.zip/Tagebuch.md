# Entwicklertagebuch

## 08.03.25
Heute habe ich die mit innoSetup auf einem Rechner installiert auf dem überhaupt kein Python installiert war und dies funktionierte nicht. Klar auch, die venv Umgebung setzt eine Python Installation vorraus und arbeitet mit absoluten Pfaden. Der nächste Versuch wird mit einer portablen Python Version durchgeführt. 
